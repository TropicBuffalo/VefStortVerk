
# Stórt verkefni 1

Fannar Már Þorvaldsson, 311092-2359, fth15@hi.is
Pétur Torfasson, 080992-2549 , pet4@hi.is

Verkefnið eru þrjár .html skrár sem keyrast í gegnum internet browser eins og google chrome/firefox o.fl.
 
index.html er forsíðan af þessum síðum og kaupa.html og um.html eru undirsvæði.
Stylesheet fyrir þessar þrjár síður eru í rót og allar myndir fyrir utan bakgrunns myndir fyrir header eru í
möppu sem kallast myndir.





